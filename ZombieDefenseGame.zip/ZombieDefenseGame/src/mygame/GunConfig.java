package mygame;

public final class GunConfig {
	// Pistol defaults
	public static final String PISTOL_NAME = "Pistol";
	public static final int PISTOL_MAG_SIZE = 12;
	public static final int PISTOL_RELOAD = 120;   // unit consistent with Weapon reload unit
	public static final int PISTOL_FIRE_RATE = 300; // ms between shots
	public static final int PISTOL_DAMAGE = 70;

	// Assault rifle defaults
	public static final String ASSAULT_RIFLE_NAME = "Assault Rifle";
	public static final int ASSAULT_RIFLE_MAG_SIZE = 30;
	public static final int ASSAULT_RIFLE_RELOAD = 240;
	public static final int ASSAULT_RIFLE_FIRE_RATE = 100;
	public static final int ASSAULT_RIFLE_DAMAGE = 55;

	// Shotgun defaults
	public static final String SHOTGUN_NAME = "Shotgun";
	public static final int SHOTGUN_MAG_SIZE = 2;
	public static final int SHOTGUN_RELOAD = 10;
	public static final int SHOTGUN_FIRE_RATE = 300;
	public static final int SHOTGUN_DAMAGE = 55;
}
